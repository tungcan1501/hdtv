<div class="yahoo-support">
<?php



$yahoo = $node;
//dsm($node);
$title = $yahoo->yahoo_name;
$nick = $yahoo->yahoo_nick;
$skyper = $yahoo->yahoo_skype;

$skyper_chat = "skype:".$skyper."?chat";
$skyper_call = "skype:".$skyper."?call";
$skyper_status = yahoo_gravity_skype_status($skyper);
$skyper_img = "images/skype_".$skyper_status.".png";
$skyper_img_call = "images/skype_call_".$skyper_status.".png";

$title = '<small>'.$title.'</small>';
$status = @file_get_contents('http://opi.yahoo.com/online?u='.$nick.'&m=t&t=1');
 ?>
  <?php
  if($status != FALSE && $status=='01')
  {
	  $ym = 'ym_online.png';
  }
  else
  {
	  $ym = 'ym_offline.png';
  }
  ?>
  <a href="ymsgr:sendim?<?php echo $nick; ?>&m="><img src="<?php echo $path.'images/'.$ym; ?>" class="ym" /></a>
  <?php echo $title ?>
  <p class="yahoo_bottom">
  <a href="<?php echo $yahoo->yahoo_gmail; ?>" alt="<?php echo $yahoo->yahoo_gmail; ?>" class="gmail yahoo"
  onclick="javascript:window.open('https://mail.google.com/mail/?view=cm&fs=1&to=<?php echo $yahoo->yahoo_gmail ?>&=1&su=&body=','popUpWindow','height=500,width=800,left=200,top=200,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no, status=yes');return false;"
  ><img src="<?php echo $path.'images/gmail.png'; ?>"  /></a>
  <a href="<?php echo $skyper_chat?>" class="skype_chat yahoo"><img src="<?php echo $path.$skyper_img; ?>" class="skype" /></a>
  <a href="<?php echo $skyper_call?>" class="skype_call yahoo"><img src="<?php echo $path.$skyper_img_call; ?>" class="skype" /></a>
  </p>
</div>